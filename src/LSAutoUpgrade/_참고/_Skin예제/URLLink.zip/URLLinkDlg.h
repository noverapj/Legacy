// URLLinkDlg.h : header file
//

#if !defined(AFX_URLLINKDLG_H__44B09F7D_0C73_45D5_BDDE_EF55AB845E14__INCLUDED_)
#define AFX_URLLINKDLG_H__44B09F7D_0C73_45D5_BDDE_EF55AB845E14__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "URLLinkButton.h"
/////////////////////////////////////////////////////////////////////////////
// CURLLinkDlg dialog

class CURLLinkDlg : public CDialog
{
// Construction
public:
	CURLLinkDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CURLLinkDlg)
	enum { IDD = IDD_URLLINK_DIALOG };
	CURLLinkButton	m_btnMyDocument;
	CURLLinkButton	m_btnShowMessage;
	CURLLinkButton	m_btnClose;
	CURLLinkButton	m_btnWebLink2;
	CURLLinkButton	m_btnMailto2;
	CURLLinkButton	m_btnLinkCustom;
	CURLLinkButton	m_btnWebLink;
	CURLLinkButton	m_btnMailto;
	CString	m_sDisplayText;
	CString	m_sURLPrefix;
	CString	m_sURL;
	CString	m_sTooltipText;
	BOOL	m_bEnable;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CURLLinkDlg)
	public:
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CURLLinkDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSetDisplayText();
	afx_msg void OnSetUrlPrefix();
	afx_msg void OnSetUrl();
	afx_msg void OnSetTooltip();
	afx_msg void OnCheckEnable();
	//}}AFX_MSG
	afx_msg LRESULT OnLinkCliked(WPARAM wParam, LPARAM lParam);

	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_URLLINKDLG_H__44B09F7D_0C73_45D5_BDDE_EF55AB845E14__INCLUDED_)

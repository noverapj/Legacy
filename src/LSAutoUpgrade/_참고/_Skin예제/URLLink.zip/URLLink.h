// URLLink.h : main header file for the URLLINK application
//

#if !defined(AFX_URLLINK_H__A1DC39A2_EC62_4964_9517_3FA9EE54C9ED__INCLUDED_)
#define AFX_URLLINK_H__A1DC39A2_EC62_4964_9517_3FA9EE54C9ED__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CURLLinkApp:
// See URLLink.cpp for the implementation of this class
//

class CURLLinkApp : public CWinApp
{
public:
	CURLLinkApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CURLLinkApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CURLLinkApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_URLLINK_H__A1DC39A2_EC62_4964_9517_3FA9EE54C9ED__INCLUDED_)

// URLLinkDlg.cpp : implementation file
//

#include "stdafx.h"
#include "URLLink.h"
#include "URLLinkDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CURLLinkDlg dialog

CURLLinkDlg::CURLLinkDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CURLLinkDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CURLLinkDlg)
	m_sDisplayText = _T("");
	m_sURLPrefix = _T("");
	m_sURL = _T("");
	m_sTooltipText = _T("");
	m_bEnable = TRUE;
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CURLLinkDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CURLLinkDlg)
	DDX_Control(pDX, IDC_OPEN_MYDOCUMENT, m_btnMyDocument);
	DDX_Control(pDX, IDC_SHOW_MESSAGE, m_btnShowMessage);
	DDX_Control(pDX, IDOK, m_btnClose);
	DDX_Control(pDX, IDC_WEB_LINK2, m_btnWebLink2);
	DDX_Control(pDX, IDC_MAIL_TO2, m_btnMailto2);
	DDX_Control(pDX, IDC_CUSTOMIZE, m_btnLinkCustom);
	DDX_Control(pDX, IDC_WEB_LINK, m_btnWebLink);
	DDX_Control(pDX, IDC_MAIL_TO, m_btnMailto);
	DDX_Text(pDX, IDC_EDIT1, m_sDisplayText);
	DDX_Text(pDX, IDC_EDIT2, m_sURLPrefix);
	DDX_Text(pDX, IDC_EDIT3, m_sURL);
	DDX_Text(pDX, IDC_EDIT4, m_sTooltipText);
	DDX_Check(pDX, IDC_CHECK_ENABLE, m_bEnable);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CURLLinkDlg, CDialog)
	//{{AFX_MSG_MAP(CURLLinkDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_SET_DISPLAY_TEXT, OnSetDisplayText)
	ON_BN_CLICKED(IDC_SET_URL_PREFIX, OnSetUrlPrefix)
	ON_BN_CLICKED(IDC_SET_URL, OnSetUrl)
	ON_BN_CLICKED(IDC_SET_TOOLTIP, OnSetTooltip)
	ON_BN_CLICKED(IDC_CHECK_ENABLE, OnCheckEnable)
	//}}AFX_MSG_MAP
	ON_REGISTERED_MESSAGE(WM_LINK_CLICKED, OnLinkCliked)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CURLLinkDlg message handlers

BOOL CURLLinkDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	
	m_btnWebLink.SetToolTipText(_T("Goto ")+m_btnWebLink.GetDefaultTipText());
	m_btnWebLink.SizeToContent();

	m_btnWebLink2.SetURL(_T("http:\\\\www.vegasoft.ws"));
	m_btnWebLink2.SetToolTipText();
	m_btnWebLink2.SizeToContent();

	m_btnMailto.SetURLPrefix(_T("Mailto:"));
	m_btnMailto.SetToolTipText();
	m_btnMailto.SizeToContent();
	
	m_btnMailto2.SetURL(_T("thanhnd@vegasoft.ws"));
	m_btnMailto2.SetURLPrefix(_T("Mailto:"));
	m_btnMailto2.SetToolTipText();
	m_btnMailto2.SetToolTipTextColor(RGB(0,100,0));
	m_btnMailto2.SizeToContent();

	m_btnLinkCustom.SetURL(_T("thanhnd@vegasoft.ws"));
	m_btnLinkCustom.SetURLPrefix(_T("Mailto:"));
	m_btnLinkCustom.SetToolTipText();
	m_btnLinkCustom.SetLinkColor(RGB(0,155,0),RGB(255,0,0),RGB(0,155,100));
	m_btnLinkCustom.SetToolTipColor(RGB(100,0,0),RGB(255,155,155));
	m_btnLinkCustom.SizeToContent();

	m_btnMyDocument.SetURL(_T("msinfo32.exe"));
	m_btnClose.SetToolTipText(_T("Show system information"));
	m_btnMyDocument.SetRegularColor(RGB(115,155,0));
	m_btnMyDocument.SizeToContent();
	
	//m_btnShowMessage.SetToolTipText(_T("Click to display a message"));
	m_btnShowMessage.SetRegularColor(RGB(0,155,155));
	m_btnShowMessage.SizeToContent();


	m_btnClose.SetToolTipText(_T("Exit"));
	m_btnClose.SetRegularColor(RGB(255,0,0));	
	m_btnClose.SizeToContent();

	m_btnLinkCustom.GetWindowText(m_sDisplayText);
	m_sTooltipText = m_btnLinkCustom.GetDefaultTipText();
	m_sURLPrefix = _T("Mailto:");
	m_sURL = _T("thanhnd@vegasoft.ws");

	UpdateData(FALSE);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CURLLinkDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CURLLinkDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CURLLinkDlg::OnSetDisplayText() 
{
	UpdateData();
	m_btnLinkCustom.SetDisplayText(m_sDisplayText);	
}

void CURLLinkDlg::OnSetUrlPrefix() 
{
	UpdateData();
	m_btnLinkCustom.SetURLPrefix(m_sURLPrefix);
}

void CURLLinkDlg::OnSetUrl() 
{
	UpdateData();
	m_btnLinkCustom.SetURL(m_sURL);
}

void CURLLinkDlg::OnSetTooltip() 
{
	UpdateData();
	m_btnLinkCustom.SetToolTipText(m_sTooltipText);
}

void CURLLinkDlg::OnCheckEnable() 
{
	UpdateData();
	m_btnLinkCustom.EnableWindow(m_bEnable);
}

LRESULT CURLLinkDlg::OnLinkCliked(WPARAM wParam, LPARAM lParam)
{
	UINT nLinkID = (UINT)wParam;

	switch(nLinkID)
	{
		case IDOK:
			OnOK();
			break;
		case IDC_SHOW_MESSAGE:
			MessageBox(_T("Hope you find this code useful!"));
			break;

	}
	
	return 0;
}




//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by URLLink.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_URLLINK_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDC_CURSOR_HAND                 129
#define IDC_WEB_LINK                    1000
#define IDC_MAIL_TO                     1001
#define IDC_WEB_LINK2                   1002
#define IDC_MAIL_TO2                    1003
#define IDC_EDIT1                       1004
#define IDC_SET_DISPLAY_TEXT            1005
#define IDC_CUSTOMIZE                   1006
#define IDC_EDIT2                       1009
#define IDC_SET_URL_PREFIX              1010
#define IDC_EDIT3                       1011
#define IDC_SET_URL                     1012
#define IDC_EDIT4                       1013
#define IDC_SET_TOOLTIP                 1014
#define IDC_SHOW_MESSAGE                1015
#define IDC_CHECK_ENABLE                1016
#define IDC_OPEN_MYDOCUMENT             1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
